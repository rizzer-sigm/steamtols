import os

import sys
import subprocess
import time
import re
import urllib.request
import zipfile
import tempfile
import shutil
import urllib.parse
import winreg
import ctypes
import win32com.client

try:
    from winotify import Notification, audio
except ImportError:
    print("[!] Missing 'winotify' package. Run `pip install winotify` for notifications.")
    Notification = None

STEAM_BASE = r"C:\Program Files (x86)\Steam"
STEAM_USERS_VDF = os.path.join(STEAM_BASE, "config", "loginusers.vdf")
DEST_FOLDER = os.path.join(STEAM_BASE, "config", "stplug-in")
STEAM_EXE_PATH = os.path.join(STEAM_BASE, "Steam.exe")
APP_DIR = r"C:\Program Files (x86)\SteamLuaSTCopier"
EXE_NAME = "SteamLuaSTCopier.exe"
FLAG_FILE = os.path.join(APP_DIR, ".installed")

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False
def create_start_menu_shortcut(target_path, shortcut_name="Steamtools V2"):
    user_start_menu = os.path.join(
        os.environ['APPDATA'],
        r"Microsoft\Windows\Start Menu\Programs\Steamtools V2"
    )
    if not os.path.exists(user_start_menu):
        os.makedirs(user_start_menu)

    shortcut_path = os.path.join(user_start_menu, shortcut_name + ".lnk")

    shell = win32com.client.Dispatch("WScript.Shell")
    shortcut = shell.CreateShortcut(shortcut_path)
    shortcut.TargetPath = target_path
    shortcut.WorkingDirectory = os.path.dirname(target_path)
    shortcut.IconLocation = target_path
    shortcut.Description = "Steamtools V2"
    shortcut.save()
    print(f"[+] Shortcut created at {shortcut_path}")

def run_as_admin():
    params = " ".join([f'"{x}"' for x in sys.argv])
    # Relaunch script as admin
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, params, None, 1
    )
    sys.exit(0)


# ===== Self-Compile and Install with admin check =====
def self_compile_and_install():
    print(f"[*] Checking flag file at {FLAG_FILE} ...")
    if os.path.exists(FLAG_FILE):
        print("[*] Already installed. Skipping compile.")
        return
    exe_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), EXE_NAME)

    if not is_admin():
        print("[!] Admin rights required to compile and install.")
        run_as_admin()

    print("[*] First run detected — compiling script to EXE...")
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"
        ])
        subprocess.check_call([
            sys.executable, "-m", "PyInstaller",
            "--onefile", "--noconsole",
            "--name", EXE_NAME.replace(".exe", ""),
            sys.argv[0]
        ])
    except Exception as e:
        print(f"[!] Failed to compile: {e}")
        return

    dist_path = os.path.join("dist", EXE_NAME)
    if not os.path.exists(dist_path):
        print("[!] Compilation finished but EXE not found.")
        return

    try:
        if not os.path.exists(APP_DIR):
            print(f"[*] Creating app dir at {APP_DIR}")
            os.makedirs(APP_DIR)

        target_path = os.path.join(APP_DIR, EXE_NAME)
        shutil.move(dist_path, target_path)
        print(f"[+] Moved compiled EXE to: {target_path}")

        print(f"[*] Creating flag file at {FLAG_FILE} ...")
        with open(FLAG_FILE, "w") as f:
            f.write("installed")

        if os.path.exists(FLAG_FILE):
            print("[✓] Flag file created successfully.")
        else:
            print("[!] Flag file creation failed or not found.")

        create_start_menu_shortcut(target_path)
        # Register App Path for quick launching
        try:
            key = winreg.CreateKey(
                winreg.HKEY_LOCAL_MACHINE,
                f"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\{EXE_NAME}"
            )
            winreg.SetValueEx(key, None, 0, winreg.REG_SZ, target_path)
            winreg.SetValueEx(key, "Path", 0, winreg.REG_SZ, APP_DIR)
            winreg.CloseKey(key)
            print("[+] App registered in Windows App Paths")
        except PermissionError:
            print("[!] Permission denied — run as administrator to register app paths.")

        # Register uninstall info for Apps & Features list (SteamTools V2)
        try:
            uninstall_key = winreg.CreateKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\SteamToolsV2"
            )
            winreg.SetValueEx(uninstall_key, "DisplayName", 0, winreg.REG_SZ, "SteamTools V2")
            winreg.SetValueEx(uninstall_key, "Publisher", 0, winreg.REG_SZ, "YourNameOrOrg")
            winreg.SetValueEx(uninstall_key, "DisplayVersion", 0, winreg.REG_SZ, "1.0.0")
            winreg.SetValueEx(uninstall_key, "InstallLocation", 0, winreg.REG_SZ, APP_DIR)
            winreg.SetValueEx(uninstall_key, "DisplayIcon", 0, winreg.REG_SZ, target_path)
            uninstall_cmd = f'cmd.exe /c rmdir /s /q "{APP_DIR}"'
            winreg.SetValueEx(uninstall_key, "UninstallString", 0, winreg.REG_SZ, uninstall_cmd)
            winreg.CloseKey(uninstall_key)
            print("[+] Registered SteamTools V2 in Apps & Features")
        except PermissionError:
            print("[!] Permission denied — run as administrator to register uninstall info.")

        # Cleanup build artifacts
        for folder in ["dist", "build"]:
            if os.path.exists(folder):
                shutil.rmtree(folder, ignore_errors=True)
        spec_file = EXE_NAME.replace(".exe", "") + ".spec"
        if os.path.exists(spec_file):
            os.remove(spec_file)

        # Relaunch installed EXE
        print("[*] Launching installed EXE...")
        subprocess.Popen([target_path])
        sys.exit(0)

    except Exception as e:
        print(f"[!] Failed to move/install EXE: {e}")



# ===== Steam Tools Functions =====
def is_protocol_registered(protocol="steamtoolsv2"):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{protocol}")
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return False


def register_protocol():
    protocol = "steamtoolsv2"
    script_path = os.path.abspath(sys.argv[0])
    command = f'"{sys.executable}" "{script_path}" "%1"'

    try:
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{protocol}")
        winreg.SetValueEx(key, None, 0, winreg.REG_SZ, f"URL: {protocol} Protocol")
        winreg.SetValueEx(key, "URL Protocol", 0, winreg.REG_SZ, "")
        shell_key = winreg.CreateKey(key, r"shell\open\command")
        winreg.SetValueEx(shell_key, None, 0, winreg.REG_SZ, command)
        winreg.CloseKey(shell_key)
        winreg.CloseKey(key)
        print(f"[+] Registered protocol {protocol} successfully.")
    except Exception as e:
        print(f"[!] Failed to register protocol: {e}")


def get_steam_user_id():
    if not os.path.exists(STEAM_USERS_VDF):
        print(f"[!] Steam loginusers.vdf not found at {STEAM_USERS_VDF}")
        return None

    with open(STEAM_USERS_VDF, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    steam_id = None
    inside_users = False
    for line in lines:
        line = line.strip()
        if line == '"users"':
            inside_users = True
            continue
        if inside_users:
            match = re.match(r'^"(\d{17})"$', line)
            if match:
                steam_id = match.group(1)
                break
            if line == '}':
                break

    if steam_id:
        print(f"[+] Found Steam User ID: {steam_id}")
        return steam_id
    else:
        print("[!] Could not find SteamID in loginusers.vdf")
        return None


def show_invalid_file_notification(file_name):
    if Notification is None:
        print(f"[!] Not a valid file: {file_name} (winotify not installed, no notif)")
        return
    toast = Notification(
        app_id="Steam Lua/ST Copier",
        title="Not a valid file >-<",
        msg=f"{file_name} is not a .lua, .st or manifest file!",
        icon=r"C:\Program Files (x86)\Steam\steam.ico"
    )
    toast.set_audio(audio.Default, loop=False)
    toast.show()


def show_fancy_notification():
    if Notification is None:
        print("[!] winotify not installed, skipping notification.")
        return
    
    toast = Notification(
        app_id="Steam Lua/ST Copier",
        title="Installed successfully >-<",
        msg="Your Lua, ST, and manifest files have been copied and Steam has been restarted! 🎉🔥",
        icon=r"C:\Program Files (x86)\Steam\steam.ico"
    )
    toast.set_audio(audio.Default, loop=False)
    toast.add_actions(label="Open Steam", launch=STEAM_EXE_PATH)
    toast.show()


def copy_file_to_dest(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    valid_exts = ['.lua', '.st']
    if os.path.basename(file_path).lower() == "manifest":
        valid_file = True
    else:
        valid_file = ext in valid_exts

    if not valid_file:
        print(f"[!] Skipping invalid file type: {file_path}")
        show_invalid_file_notification(os.path.basename(file_path))
        return False

    if not os.path.exists(file_path):
        print(f"[!] File not found: {file_path}")
        return False

    file_name = os.path.basename(file_path)
    dest_path = os.path.join(DEST_FOLDER, file_name)

    try:
        print(f"[+] Copying {file_name} to stplug-in folder...")
        with open(file_path, 'rb') as src, open(dest_path, 'wb') as dst:
            dst.write(src.read())
        print(f"    [✓] Copied to {dest_path}")
        return True
    except Exception as e:
        print(f"[!] Failed to copy {file_name}: {e}")
        return False


def restart_steam():
    print("[*] Restarting Steam...")
    subprocess.run(['taskkill', '/F', '/IM', 'steam.exe'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(2)
    if os.path.exists(STEAM_EXE_PATH):
        subprocess.Popen([STEAM_EXE_PATH])
        print("[✓] Steam restarted.")
    else:
        print(f"[!] Steam executable not found at {STEAM_EXE_PATH}")


def download_and_extract_zip(url):
    if url.startswith("http//"):
        url = url.replace("http//", "http://", 1)
    elif url.startswith("https//"):
        url = url.replace("https//", "https://", 1)

    print(f"[+] Downloading ZIP from: {url}")
    tmp_dir = tempfile.mkdtemp(prefix="steamtools_")
    zip_path = os.path.join(tmp_dir, "downloaded.zip")

    try:
        urllib.request.urlretrieve(url, zip_path)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(tmp_dir)

        files_copied = 0
        for root, dirs, files in os.walk(tmp_dir):
            for file in files:
                if file.lower().endswith(('.lua', '.st')) or file.lower() == 'manifest':
                    full_path = os.path.join(root, file)
                    if copy_file_to_dest(full_path):
                        files_copied += 1

        return files_copied > 0
    except Exception as e:
        print(f"[!] Failed to download/extract: {e}")
        return False
    finally:
        shutil.rmtree(tmp_dir)


def main():
    if not is_protocol_registered():
        register_protocol()

    steam_id = get_steam_user_id()

    if len(sys.argv) == 2 and sys.argv[1].lower().startswith("steamtoolsv2://"):
        url = urllib.parse.unquote(sys.argv[1][len("steamtoolsv2://"):])
        if url.lower().endswith(".zip"):
            if os.path.exists(DEST_FOLDER) and download_and_extract_zip(url):
                restart_steam()
                show_fancy_notification()
        return

    if len(sys.argv) < 2:
        if Notification is not None:
            toast = Notification(
                app_id="Steam Lua/ST Copier",
                title="Drag a lua or st file uwu",
                msg="Please drag a lua or ST file plewase",
                icon=r"C:\Program Files (x86)\Steam\steam.ico"
            )
            toast.set_audio(audio.Default, loop=False)
            toast.add_actions(label="Open Steam", launch=STEAM_EXE_PATH)
            toast.show()
        return

    if not os.path.exists(DEST_FOLDER):
        print(f"[!] Destination folder not found: {DEST_FOLDER}")
        return

    all_success = all(copy_file_to_dest(path) for path in sys.argv[1:])
    if all_success:
        restart_steam()
        show_fancy_notification()


if __name__ == "__main__":
    self_compile_and_install()
    main()
